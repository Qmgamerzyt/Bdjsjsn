// 🌐 Clean Deploy Script (with debug + safe exit)

require("dotenv").config();
const { REST, Routes } = require("discord.js");
const fs = require("fs");
const path = require("path");

const TOKEN = process.env.TOKEN;
const CLIENT_ID = process.env.CLIENT_ID;

if (!TOKEN || !CLIENT_ID) {
  console.error("❌ TOKEN or CLIENT_ID missing in .env");
  process.exit(1);
}

const commands = [];
const basePath = path.join(__dirname, "commands");
const folders = fs.readdirSync(basePath);

console.log("🔍 Reading commands...");
for (const folder of folders) {
  const folderPath = path.join(basePath, folder);
  if (!fs.lstatSync(folderPath).isDirectory()) continue;

  const files = fs.readdirSync(folderPath).filter(f => f.endsWith(".js"));
  for (const file of files) {
    const filePath = path.join(folderPath, file);
    try {
      const command = require(filePath);
      if (command.data && command.execute) {
        commands.push(command.data.toJSON());
        console.log(`✅ Loaded: ${folder}/${file}`);
      } else {
        console.warn(`⚠️ Skipped invalid command: ${folder}/${file}`);
      }
    } catch (err) {
      console.error(`❌ Error loading ${file}:`, err);
    }
  }
}

const rest = new REST({ version: "10" }).setToken(TOKEN);

(async () => {
  try {
    console.log("\n🧹 Deleting previous global commands...");
    await rest.put(Routes.applicationCommands(CLIENT_ID), { body: [] });
    console.log("✅ Old commands deleted.");

    console.log(`🚀 Deploying ${commands.length} new commands...`);
    const data = await rest.put(Routes.applicationCommands(CLIENT_ID), { body: commands });
    console.log(`🎉 Deployed ${data.length} commands successfully!`);
  } catch (err) {
    console.error("❌ Deployment failed:", err);
  }

  // Force exit after 10s max
  setTimeout(() => process.exit(0), 10000);
})();