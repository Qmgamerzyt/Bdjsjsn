// models/Reminder.js
const mongoose = require('mongoose');

const reminderSchema = new mongoose.Schema({
  userId: String,
  guildId: String,
  channelId: String,
  frequency: String, // Daily / Once / Weekly:Mon,Tue
  time: String, // HH:mm format
  timezone: String, // e.g., GMT+5
  spam: Number,
  message: String,
  ping: String, // user or role mention (optional)
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Reminder', reminderSchema);