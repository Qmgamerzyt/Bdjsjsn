// events/guildMemberAdd.js
const Welcome = require("../models/Welcome");

module.exports = {
  name: "guildMemberAdd",

  async execute(member) {
    try {
      const settings = await Welcome.findOne({ guildId: member.guild.id });
      if (!settings) return;

      const channel = member.guild.channels.cache.get(settings.channelId);
      if (!channel || !channel.isTextBased()) return;

      const message = settings.message.replace(/{user}/g, `<@${member.id}>`);
      await channel.send({ content: message });
    } catch (err) {
      console.error("❌ Welcome Message Error:", err);
    }
  }
};