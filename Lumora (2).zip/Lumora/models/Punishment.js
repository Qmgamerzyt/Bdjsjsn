const mongoose = require("mongoose");

const punishmentSchema = new mongoose.Schema({
  userId: {
    type: String,
    required: true
  },
  guildId: {
    type: String,
    required: true
  },
  type: {
    type: String,
    enum: ["ban", "kick", "timeout", "tempban"], // ✅ tempban added
    required: true
  },
  reason: {
    type: String,
    required: true
  },
  moderatorId: {
    type: String,
    required: true
  },
  timestamp: {
    type: Date,
    default: Date.now
  },
  duration: {
    type: String,
    default: null // only used for timeout and tempban
  }
});

module.exports = mongoose.model("Punishment", punishmentSchema);