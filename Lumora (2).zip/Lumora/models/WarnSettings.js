const mongoose = require("mongoose");

const warnSettingsSchema = new mongoose.Schema({
  guildId: { type: String, required: true, unique: true },
  warns: { type: Number, required: true },
  action: { type: String, enum: ["kick", "ban", "timeout"], required: true },
  duration: { type: String } // Only used for timeout
});

module.exports = mongoose.model("WarnSettings", warnSettingsSchema);