require("dotenv").config();
const { Client, GatewayIntentBits, Collection, Partials } = require("discord.js");
const fs = require("fs");
const path = require("path");
const mongoose = require("mongoose");
const express = require("express");
const moment = require("moment-timezone");

// === Models ===
const Reminder = require("./models/Reminder");
const Welcome = require("./models/Welcome");

// === Voice Channels (Status + Server Count) ===
const BOT_STATUS_CHANNEL_ID = "1384781516143591424";
const SERVER_COUNT_CHANNEL_ID = "1385176166188716123";

// === Initialize Bot ===
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildVoiceStates,
  ],
  partials: [Partials.Channel],
});

client.commands = new Collection();

// === Load Slash Commands ===
const commandsPath = path.join(__dirname, "commands");
for (const folder of fs.readdirSync(commandsPath)) {
  const folderPath = path.join(commandsPath, folder);
  const commandFiles = fs.readdirSync(folderPath).filter(file => file.endsWith(".js"));

  for (const file of commandFiles) {
    const command = require(path.join(folderPath, file));
    if (command.data && command.execute) {
      client.commands.set(command.data.name, command);
    } else {
      console.warn(`⚠️ Invalid command skipped: ${folder}/${file}`);
    }
  }
}

// === Slash Command Interaction ===
client.on("interactionCreate", async interaction => {
  try {
    if (interaction.isChatInputCommand()) {
      const command = client.commands.get(interaction.commandName);
      if (!command) return;
      await command.execute(interaction, client);
    }

    // === Modal Reminder ===
    else if (interaction.isModalSubmit() && interaction.customId === "reminderModal") {
      const frequency = interaction.fields.getTextInputValue("frequency");
      const time = interaction.fields.getTextInputValue("time");
      let timezone = interaction.fields.getTextInputValue("timezone").replace(/\s/g, "");
      const spam = parseInt(interaction.fields.getTextInputValue("spam"));
      const message = interaction.fields.getTextInputValue("message");
      const channelId = interaction.channelId;

      if (/^GMT[+-]\d{1,2}$/.test(timezone)) {
        const offset = timezone.slice(3);
        timezone = `Etc/GMT${offset.startsWith("+") ? `-${offset.slice(1)}` : `+${offset.slice(1)}`}`;
      }

      if (!moment.tz.zone(timezone)) {
        return interaction.reply({ content: "❌ Invalid timezone.", ephemeral: true });
      }

      if (isNaN(spam) || spam < 1 || spam > 5) {
        return interaction.reply({ content: "❌ Spam must be between 1 and 5.", ephemeral: true });
      }

      await Reminder.create({
        userId: interaction.user.id,
        guildId: interaction.guildId,
        channelId,
        frequency,
        time,
        timezone,
        spam,
        message,
      });

      await interaction.reply({
        content: `✅ Reminder saved!\n**Freq:** ${frequency}\n**Time:** ${time} ${timezone}\n**Spam:** ${spam}x\n**Msg:** ${message}`,
        ephemeral: true,
      });
    }

  } catch (err) {
    console.error("❌ Interaction Error:", err);
    if (!interaction.replied) {
      await interaction.reply({ content: "⚠️ Command error.", ephemeral: true });
    }
  }
});

// === Reminder Scheduler ===
setInterval(async () => {
  const now = moment.utc();
  const reminders = await Reminder.find();

  for (const reminder of reminders) {
    const currentTime = moment.tz(now, reminder.timezone);
    const [hr, min] = reminder.time.split(":").map(Number);
    const today = currentTime.format("ddd").toLowerCase();

    const isMatch = currentTime.hour() === hr && currentTime.minute() === min;
    const freqMatch =
      reminder.frequency.toLowerCase() === "daily" ||
      (reminder.frequency.toLowerCase().startsWith("weekly") && reminder.frequency.toLowerCase().includes(today)) ||
      reminder.frequency.toLowerCase() === "once";

    if (isMatch && freqMatch) {
      const guild = client.guilds.cache.get(reminder.guildId);
      if (!guild) continue;

      const channel = guild.channels.cache.get(reminder.channelId);
      if (!channel?.isTextBased?.()) continue;

      const msg = `${reminder.ping || ""} ⏰ Reminder:\n${reminder.message}`;
      for (let i = 0; i < Math.min(reminder.spam, 5); i++) {
        await channel.send(msg).catch(() => {});
      }

      if (reminder.frequency.toLowerCase() === "once") {
        await Reminder.findByIdAndDelete(reminder._id);
      }
    }
  }
}, 60 * 1000);

// === Bot Status Updater ===
async function updateVCStatus() {
  const statusVC = await client.channels.fetch(BOT_STATUS_CHANNEL_ID).catch(() => null);
  const serverVC = await client.channels.fetch(SERVER_COUNT_CHANNEL_ID).catch(() => null);
  if (!statusVC || !serverVC) return;

  const statusName = client.ws.status === 0 ? "🟢 Bot: Online" : "🔴 Bot: Offline";
  const serverName = `🌐 Servers: ${client.guilds.cache.size}`;

  if (statusVC.name !== statusName) await statusVC.setName(statusName).catch(() => {});
  if (serverVC.name !== serverName) await serverVC.setName(serverName).catch(() => {});
}
setInterval(updateVCStatus, 60 * 1000);

// === Welcome Message ===
client.on("guildMemberAdd", async member => {
  try {
    const config = await Welcome.findOne({ guildId: member.guild.id });
    if (!config) return;

    const channel = member.guild.channels.cache.get(config.channelId);
    if (!channel?.isTextBased?.()) return;

    const message = config.message.replace(/\{user\}/g, `<@${member.id}>`);
    await channel.send(message);
  } catch (err) {
    console.error("❌ Welcome Error:", err);
  }
});

// === MongoDB Connection ===
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log("✅ MongoDB connected"))
  .catch(err => console.error("❌ MongoDB error:", err));

// === Express Uptime for Replit ===
const app = express();
app.get("/", (_, res) => res.send("✅ Bot is online"));
app.listen(3000, () => console.log("🌐 Express listening on port 3000"));

// === Crash Handling ===
process.on("unhandledRejection", err => console.error("🔴 Unhandled Rejection:", err));
process.on("uncaughtException", err => console.error("🔴 Uncaught Exception:", err));

// === Bot Login ===
client.login(process.env.TOKEN);