// events/interactionModal.js
module.exports = {
  name: 'interactionCreate',
  async execute(interaction) {
    if (!interaction.isModalSubmit()) return;

    if (interaction.customId === 'reminderModal') {
      const frequency = interaction.fields.getTextInputValue('frequency');
      const channelId = interaction.fields.getTextInputValue('channel');
      const time = interaction.fields.getTextInputValue('time');
      const timezone = interaction.fields.getTextInputValue('timezone');
      const spam = interaction.fields.getTextInputValue('spam');
      const message = interaction.fields.getTextInputValue('message');

      // Validate spam limit
      const spamCount = Math.min(Math.max(parseInt(spam), 1), 5);

      const reminderData = {
        userId: interaction.user.id,
        guildId: interaction.guildId,
        frequency,
        channelId,
        time,
        timezone,
        spamCount,
        message,
      };

      // You can save to DB here or push to an array temporarily
      await interaction.reply({
        content: `✅ Reminder set!\n**Frequency**: ${frequency}\n**Channel ID**: ${channelId}\n**Time**: ${time} ${timezone}\n**Spam**: ${spamCount}x\n**Message**: ${message}`,
        ephemeral: true
      });
    }
  }
};