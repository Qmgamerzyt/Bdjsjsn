const { SlashCommandBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('reminderedit')
    .setDescription('Edit an existing reminder'),

  async execute(interaction) {
    const modal = new ModalBuilder()
      .setCustomId('editReminderModal')
      .setTitle('Edit Reminder');

    const idInput = new TextInputBuilder()
      .setCustomId('reminderId')
      .setLabel('Reminder ID')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    const timeInput = new TextInputBuilder()
      .setCustomId('newTime')
      .setLabel('New Time (HH:mm)')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    const timezoneInput = new TextInputBuilder()
      .setCustomId('newTimezone')
      .setLabel('New Timezone (e.g. Asia/Karachi)')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    const messageInput = new TextInputBuilder()
      .setCustomId('newMessage')
      .setLabel('New Message')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(true);

    modal.addComponents(
      new ActionRowBuilder().addComponents(idInput),
      new ActionRowBuilder().addComponents(timeInput),
      new ActionRowBuilder().addComponents(timezoneInput),
      new ActionRowBuilder().addComponents(messageInput),
    );

    await interaction.showModal(modal);
  },
};