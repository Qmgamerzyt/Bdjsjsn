const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ping')
    .setDescription('Check bot ping to Discord API'),

  cooldown: 5,

  async execute(interaction) {
    const apiPing = interaction.client.ws.ping;

    await interaction.reply(`🏓 Pong!\n**API Latency:** ${apiPing}ms`);
  },
};