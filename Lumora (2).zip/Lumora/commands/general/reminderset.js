const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder
} = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('reminderset')
    .setDescription('Set an advanced reminder')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    const modal = new ModalBuilder()
      .setCustomId('reminderModal')
      .setTitle('Set a Reminder');

    const frequencyInput = new TextInputBuilder()
      .setCustomId('frequency')
      .setLabel('Frequency (Daily / Once / Weekly:Mon,Tue...)')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    const timeInput = new TextInputBuilder()
      .setCustomId('time')
      .setLabel('Time (24h format, e.g. 14:30)')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    const timezoneInput = new TextInputBuilder()
      .setCustomId('timezone')
      .setLabel('Timezone (e.g. GMT+5)')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    const spamInput = new TextInputBuilder()
      .setCustomId('spam')
      .setLabel('Spam Count (1 to 5)')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    const messageInput = new TextInputBuilder()
      .setCustomId('message')
      .setLabel('Reminder Message')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(true);

    modal.addComponents(
      new ActionRowBuilder().addComponents(frequencyInput),
      new ActionRowBuilder().addComponents(timeInput),
      new ActionRowBuilder().addComponents(timezoneInput),
      new ActionRowBuilder().addComponents(spamInput),
      new ActionRowBuilder().addComponents(messageInput)
    );

    await interaction.showModal(modal);
  }
};