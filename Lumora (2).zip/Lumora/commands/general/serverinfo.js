const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const moment = require("moment");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("serverinfo")
    .setDescription("📊 Show detailed information about the server"),

  async execute(interaction) {
    const { guild } = interaction;

    await guild.fetch(); // ensures we get full data
    const owner = await guild.fetchOwner();

    const totalChannels = guild.channels.cache.size;
    const textChannels = guild.channels.cache.filter(ch => ch.type === 0).size;
    const voiceChannels = guild.channels.cache.filter(ch => ch.type === 2).size;

    const totalMembers = guild.memberCount;
    const bots = guild.members.cache.filter(member => member.user.bot).size;
    const humans = totalMembers - bots;

    const roles = guild.roles.cache;
    const totalRoles = roles.size;
    const managedRoles = roles.filter(r => r.managed).size;
    const dangerousRoles = roles.filter(r => 
      r.permissions.has("Administrator") || 
      r.permissions.has("BanMembers") || 
      r.permissions.has("KickMembers")
    ).size;

    const embed = new EmbedBuilder()
      .setTitle("📊 Server Information")
      .setThumbnail(guild.iconURL({ dynamic: true }))
      .addFields(
        { name: "📛 Name", value: guild.name, inline: true },
        { name: "🆔 ID", value: guild.id, inline: true },
        { name: "👑 Owner", value: `<@${owner.id}>`, inline: true },
        { name: "📅 Created", value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:R>`, inline: true },

        { name: "📁 Channels", value: `📄 Text: ${textChannels}\n🔊 Voice: ${voiceChannels}\n📦 Total: ${totalChannels}`, inline: true },
        { name: "👥 Members", value: `🧍 Users: ${humans}\n🤖 Bots: ${bots}\n👤 Total: ${totalMembers}`, inline: true },

        { name: "🏷️ Roles", value: `🔢 Total: ${totalRoles}\n🔐 Managed: ${managedRoles}\n⚠️ Dangerous: ${dangerousRoles}`, inline: true }
      )
      .setColor("#ff3131")
      .setFooter({ text: `Requested by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};