const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('roleinfo')
    .setDescription('Get information about a specific role')
    .addRoleOption(option =>
      option.setName('role')
        .setDescription('The role to get info about')
        .setRequired(true)
    ),

  async execute(interaction) {
    const role = interaction.options.getRole('role');

    // Force fetch all members to avoid cache issues
    await interaction.guild.members.fetch();

    // List members with the role (max 30 to avoid embed limit)
    const members = role.members.map(member => `${member.user.tag}`).slice(0, 30);

    const embed = {
      color: role.color || 0x00AE86,
      title: `Role Info: ${role.name}`,
      fields: [
        { name: '🆔 Role ID', value: role.id, inline: true },
        { name: '📌 Mentionable', value: role.mentionable ? 'Yes' : 'No', inline: true },
        { name: '📌 Hoisted', value: role.hoist ? 'Yes' : 'No', inline: true },
        { name: '🎨 Color', value: role.hexColor || 'Default', inline: true },
        { name: '👥 Total Members', value: `${role.members.size}`, inline: true },
        {
          name: '👤 Sample Members',
          value: members.length > 0 ? members.join('\n') : 'No users with this role',
        }
      ],
      timestamp: new Date()
    };

    await interaction.reply({ embeds: [embed] });
  }
};