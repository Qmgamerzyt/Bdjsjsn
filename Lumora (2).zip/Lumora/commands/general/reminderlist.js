const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const Reminder = require("../../models/Reminder");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("reminderlist")
    .setDescription("View all your saved reminders"),

  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });

    try {
      const reminders = await Reminder.find({
        userId: interaction.user.id,
        guildId: interaction.guildId,
      });

      if (reminders.length === 0) {
        return interaction.editReply("🔍 You have no saved reminders.");
      }

      // Send each reminder embed with ID in content (outside embed)
      for (let i = 0; i < reminders.length; i++) {
        const r = reminders[i];

        const embed = new EmbedBuilder()
          .setColor("Blue")
          .setTitle(`🔔 Reminder #${i + 1}`)
          .addFields(
            { name: "Message", value: r.message || "None", inline: false },
            { name: "Frequency", value: r.frequency, inline: true },
            { name: "Time", value: `${r.time} ${r.timezone}`, inline: true },
            { name: "Spam", value: `${r.spam}x`, inline: true },
            { name: "Channel", value: `<#${r.channelId}>`, inline: false }
          );

        await interaction.followUp({
          content: `🆔 ID: \`${r._id}\``, // ✅ ID is now outside embed and copyable
          embeds: [embed],
          ephemeral: true,
        });
      }
    } catch (err) {
      console.error("❌ Error fetching reminders:", err);
      await interaction.editReply("❌ Failed to fetch reminders.");
    }
  },
};