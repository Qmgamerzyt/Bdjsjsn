const { SlashCommandBuilder, EmbedBuilder, ChannelType } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("channelinfo")
    .setDescription("Get info about a channel")
    .addChannelOption(option =>
      option.setName("channel")
        .setDescription("Select a channel")
        .setRequired(false)
    ),

  async execute(interaction) {
    const channel = interaction.options.getChannel("channel") || interaction.channel;

    const typeMap = {
      [ChannelType.GuildText]: "Text Channel",
      [ChannelType.GuildVoice]: "Voice Channel",
      [ChannelType.GuildCategory]: "Category",
      [ChannelType.GuildAnnouncement]: "Announcement Channel",
      [ChannelType.AnnouncementThread]: "Announcement Thread",
      [ChannelType.PublicThread]: "Public Thread",
      [ChannelType.PrivateThread]: "Private Thread",
      [ChannelType.GuildStageVoice]: "Stage Channel",
      [ChannelType.GuildForum]: "Forum",
      [ChannelType.GuildMedia]: "Media Channel"
    };

    const embed = new EmbedBuilder()
      .setColor("Blurple")
      .setTitle("📺 Channel Information")
      .addFields(
        { name: "Name", value: channel.name, inline: true },
        { name: "ID", value: `\`${channel.id}\``, inline: true },
        { name: "Type", value: typeMap[channel.type] || "Unknown", inline: true },
        { name: "NSFW", value: channel.nsfw ? "Yes" : "No", inline: true },
        { name: "Created On", value: `<t:${Math.floor(channel.createdTimestamp / 1000)}:F>`, inline: false }
      );

    await interaction.reply({ embeds: [embed], ephemeral: false });
  }
};