// commands/info/memberinfo.js
const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("memberinfo")
    .setDescription("📋 Get basic info about a server member")
    .addUserOption(option =>
      option.setName("user")
        .setDescription("The member to inspect")
        .setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),

  async execute(interaction) {
    const target = interaction.options.getUser("user");
    const member = interaction.guild.members.cache.get(target.id);

    if (!member) {
      return interaction.reply({ content: "❌ Member not found in this server.", ephemeral: true });
    }

    const embed = new EmbedBuilder()
      .setTitle(`👤 Member Info: ${target.tag}`)
      .setThumbnail(target.displayAvatarURL({ dynamic: true }))
      .setColor("#00b0f4")
      .addFields(
        { name: "🆔 User ID", value: `${target.id}`, inline: true },
        { name: "📅 Account Created", value: `<t:${Math.floor(target.createdTimestamp / 1000)}:R>`, inline: true },
        { name: "📥 Joined Server", value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>`, inline: true },
        { name: "🎭 Roles", value: member.roles.cache
            .filter(role => role.id !== interaction.guild.id)
            .map(role => `<@&${role.id}>`)
            .join(", ") || "No roles", inline: false }
      )
      .setFooter({ text: `Requested by ${interaction.user.tag}` })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};