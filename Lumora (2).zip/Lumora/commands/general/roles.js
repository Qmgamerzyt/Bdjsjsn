const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('roles')
    .setDescription('Lists all roles in this server'),

  async execute(interaction) {
    const roles = interaction.guild.roles.cache
      .filter(role => role.name !== '@everyone')
      .map(role => `${role.name} (${role.id})`)
      .join('\n');

    if (!roles) {
      return interaction.reply('No roles found in this server.');
    }

    await interaction.reply({
      content: `**Roles in this server:**\n${roles.length > 1900 ? roles.slice(0, 1900) + '\n...too many roles!' : roles}`,
      ephemeral: false
    });
  },
};