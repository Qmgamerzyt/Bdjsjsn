// commands/general/purge.js
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('purge')
    .setDescription('Bulk delete messages')
    .addIntegerOption(option =>
      option.setName('amount')
        .setDescription('Number of messages to delete')
        .setRequired(true)
    ),
  async execute(interaction) {
    const amount = interaction.options.getInteger('amount');
    if (!interaction.member.permissions.has('ManageMessages')) {
      return interaction.reply({ content: '❌ You don’t have permission to manage messages.', ephemeral: true });
    }

    await interaction.deferReply({ ephemeral: true });

    let deleted = 0;
    let remaining = amount;

    try {
      while (remaining > 0) {
        const toDelete = Math.min(remaining, 100);
        const messages = await interaction.channel.messages.fetch({ limit: toDelete });
        const filtered = messages.filter(msg => (Date.now() - msg.createdTimestamp) < 14 * 24 * 60 * 60 * 1000);
        const deletedMessages = await interaction.channel.bulkDelete(filtered, true);
        deleted += deletedMessages.size;
        remaining -= toDelete;

        // Break if not enough messages to delete
        if (filtered.size < toDelete) break;
      }

      await interaction.editReply({ content: `✅ Deleted ${deleted} message(s).` });
    } catch (error) {
      console.error(error);
      await interaction.editReply({ content: '❌ An error occurred while trying to purge messages.' });
    }
  }
};