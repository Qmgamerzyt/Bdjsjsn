// commands/reminder/reminderremove.js
const { SlashCommandBuilder } = require('discord.js');
const Reminder = require('../../models/Reminder');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('reminderremove')
    .setDescription('Delete a reminder by its ID')
    .addStringOption(option =>
      option.setName('id')
        .setDescription('The reminder ID to delete')
        .setRequired(true)
    ),

  async execute(interaction) {
    const id = interaction.options.getString('id');

    // Optional: Only allow admins
    if (!interaction.member.permissions.has('Administrator')) {
      return interaction.reply({
        content: '❌ You must be an administrator to delete reminders.',
        ephemeral: true
      });
    }

    try {
      const deleted = await Reminder.findByIdAndDelete(id);

      if (!deleted) {
        return interaction.reply({
          content: `❌ No reminder found with ID: \`${id}\``,
          ephemeral: true
        });
      }

      return interaction.reply({
        content: `✅ Reminder with ID \`${id}\` has been deleted.`,
        ephemeral: true
      });
    } catch (err) {
      console.error("❌ Failed to delete reminder:", err);
      return interaction.reply({
        content: '❌ Failed to delete reminder. Please try again later.',
        ephemeral: true
      });
    }
  }
};