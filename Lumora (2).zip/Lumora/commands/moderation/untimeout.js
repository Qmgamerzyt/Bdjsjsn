// commands/untimeout.js
const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('untimeout')
    .setDescription('Remove timeout from a user')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('User to untimeout')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('reason')
        .setDescription('Reason for untimeout')
        .setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const user = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const member = interaction.guild.members.cache.get(user.id);

    if (!member) {
      return interaction.reply({ content: 'User not found in this server.', ephemeral: true });
    }

    if (!member.communicationDisabledUntil) {
      return interaction.reply({ content: 'This user is not timed out.', ephemeral: true });
    }

    try {
      await member.timeout(null, reason);

      const embed = new EmbedBuilder()
        .setTitle(`${user.tag} has been un-timed out`)
        .addFields(
          { name: 'Reason', value: reason },
          { name: 'Moderator', value: interaction.user.tag }
        )
        .setColor('Green')
        .setTimestamp();

      await interaction.reply({ embeds: [embed] });

      try {
        await user.send(`You have been un-timed out in **${interaction.guild.name}**.\nReason: ${reason}`);
      } catch (e) {
        console.log(`Failed to DM ${user.tag}`);
      }

    } catch (error) {
      console.error(error);
      await interaction.reply({ content: 'Failed to remove timeout.', ephemeral: true });
    }
  }
};