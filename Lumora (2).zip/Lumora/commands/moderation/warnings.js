const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require("discord.js");
const Warning = require("../../models/Warn");
const moment = require("moment");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("warnings")
    .setDescription("🔎 Check a user's warnings")
    .addUserOption(option =>
      option.setName("user")
        .setDescription("User to view warnings for")
        .setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const user = interaction.options.getUser("user");

    const warns = await Warning.find({
      guildId: interaction.guildId,
      userId: user.id
    }).sort({ timestamp: -1 });

    if (!warns.length) {
      return interaction.reply({
        content: `✅ **${user.tag}** has no warnings.`,
        ephemeral: true
      });
    }

    const embed = new EmbedBuilder()
      .setTitle(`⚠️ Warnings for ${user.tag}`)
      .setColor("Orange")
      .setFooter({ text: `Total warnings: ${warns.length}` });

    warns.slice(0, 10).forEach((warn, index) => {
      embed.addFields({
        name: `#${index + 1} — ${moment(warn.timestamp).format("DD MMM YYYY, HH:mm")}`,
        value: `**Reason:** ${warn.reason}\n**By:** <@${warn.moderatorId}>`,
        inline: false
      });
    });

    await interaction.reply({ embeds: [embed], ephemeral: true });
  }
};