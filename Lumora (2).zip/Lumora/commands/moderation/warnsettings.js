const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require("discord.js");
const WarnSettings = require("../../models/WarnSettings");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("warnsettings")
    .setDescription("Set automatic actions after a number of warnings")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addIntegerOption(option =>
      option.setName("warns")
        .setDescription("Number of warnings before action is triggered")
        .setRequired(true)
    )
    .addStringOption(option =>
      option.setName("action")
        .setDescription("Action to take")
        .addChoices(
          { name: "Kick", value: "kick" },
          { name: "Ban", value: "ban" },
          { name: "Timeout", value: "timeout" }
        )
        .setRequired(true)
    )
    .addStringOption(option =>
      option.setName("duration")
        .setDescription("Timeout duration (e.g. 10m, 1h, 1d) — only for timeout")
        .setRequired(false)
    ),

  async execute(interaction) {
    const guildId = interaction.guildId;
    const warns = interaction.options.getInteger("warns");
    const action = interaction.options.getString("action");
    const duration = interaction.options.getString("duration");

    if (action === "timeout" && !duration) {
      return interaction.reply({
        content: "❌ You must specify a timeout `duration` (e.g., 10m, 1h, 1d).",
        ephemeral: true
      });
    }

    try {
      await WarnSettings.findOneAndUpdate(
        { guildId },
        { warns, action, duration: action === "timeout" ? duration : null },
        { upsert: true, new: true }
      );

      const embed = new EmbedBuilder()
        .setColor("Green")
        .setTitle("⚙️ Warn Settings Updated")
        .setDescription(`Action: **${action}**
Warns Required: **${warns}**
${action === "timeout" ? `Duration: **${duration}**` : ""}`);

      await interaction.reply({ embeds: [embed], ephemeral: true });
    } catch (err) {
      console.error("WarnSettings error:", err);
      await interaction.reply({
        content: "❌ Failed to update warn settings.",
        ephemeral: true
      });
    }
  }
};