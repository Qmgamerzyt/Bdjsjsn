const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require("discord.js");
const ms = require("ms");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("temprole")
    .setDescription("⏳ Temporarily assign one or more roles to multiple users.")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
    .addStringOption(option =>
      option.setName("users")
        .setDescription("Mention users (e.g., @User1 @User2)")
        .setRequired(true))
    .addStringOption(option =>
      option.setName("roles")
        .setDescription("Mention roles (e.g., @Muted @Helper)")
        .setRequired(true))
    .addStringOption(option =>
      option.setName("duration")
        .setDescription("Duration like 10m, 1h, 2d")
        .setRequired(true)),

  async execute(interaction) {
    await interaction.deferReply(); // Avoid "Unknown interaction" on slow loops

    const usersRaw = interaction.options.getString("users");
    const rolesRaw = interaction.options.getString("roles");
    const durationStr = interaction.options.getString("duration");
    const durationMs = ms(durationStr);

    if (!durationMs || durationMs < 1000) {
      return interaction.editReply({ content: "❌ Invalid duration format like `10m`, `1h`, `1d`." });
    }

    const userIds = [...usersRaw.matchAll(/<@!?(\d+)>/g)].map(match => match[1]);
    const roleIds = [...rolesRaw.matchAll(/<@&(\d+)>/g)].map(match => match[1]);

    const added = [];
    const failed = [];

    for (const userId of userIds) {
      const member = await interaction.guild.members.fetch(userId).catch(() => null);
      if (!member) {
        failed.push(`❌ <@${userId}> (User not found)`);
        continue;
      }

      for (const roleId of roleIds) {
        const role = interaction.guild.roles.cache.get(roleId);
        const me = interaction.guild.members.me;

        if (
          !role ||
          !me.permissions.has(PermissionFlagsBits.ManageRoles) ||
          role.position >= me.roles.highest.position
        ) {
          failed.push(`❌ ${member.user.tag} - <@&${roleId}> (Permission issue or role too high)`);
          continue;
        }

        try {
          await member.roles.add(role);
          added.push(`✅ ${member.user.tag} ➕ <@&${roleId}> for \`${durationStr}\``);

          setTimeout(async () => {
            try {
              await member.roles.remove(role);
              console.log(`⏱️ Removed ${role.name} from ${member.user.tag}`);
            } catch (err) {
              console.error(`❌ Failed to remove ${role.name} from ${member.user.tag}`);
            }
          }, durationMs);
        } catch (err) {
          console.error("❌ Role add error:", err);
          failed.push(`❌ ${member.user.tag} - <@&${roleId}> (Error during role add)`);
        }
      }
    }

    const embed = new EmbedBuilder()
      .setTitle("⏳ Temporary Role Assignment")
      .setColor("Green")
      .addFields(
        { name: "⏱️ Duration", value: `\`${durationStr}\``, inline: true },
        { name: "✅ Assigned", value: added.length ? added.join("\n") : "None", inline: false },
        { name: "❌ Failed", value: failed.length ? failed.join("\n") : "None", inline: false }
      )
      .setFooter({ text: `Requested by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() })
      .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
  }
};