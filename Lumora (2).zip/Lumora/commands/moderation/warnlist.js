const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const Warn = require("../../models/Warn");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("warnlist")
    .setDescription("View the warning count of all users in this server"),

  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });

    try {
      const warnings = await Warn.find({ guildId: interaction.guild.id });

      if (!warnings.length) {
        return interaction.editReply("✅ No users have warnings in this server.");
      }

      const warnCount = new Map();

      // Count warns per user
      for (const warn of warnings) {
        warnCount.set(warn.userId, (warnCount.get(warn.userId) || 0) + 1);
      }

      const lines = [];

      for (const [userId, count] of warnCount.entries()) {
        lines.push(`<@${userId}> — **${count} warn${count > 1 ? "s" : ""}**`);
      }

      const embed = new EmbedBuilder()
        .setTitle("⚠️ Warn List")
        .setDescription(lines.join("\n"))
        .setColor("Yellow")
        .setFooter({ text: `Total warned users: ${warnCount.size}` });

      await interaction.editReply({ embeds: [embed] });

    } catch (error) {
      console.error("❌ Error fetching warn list:", error);
      await interaction.editReply("❌ Failed to fetch warn list.");
    }
  },
};