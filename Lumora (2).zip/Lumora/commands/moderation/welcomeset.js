// commands/admin/welcomeset.js
const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require("discord.js");
const Welcome = require("../../models/Welcome");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("welcomeset")
    .setDescription("📥 Set the welcome message and channel")
    .addChannelOption(option =>
      option.setName("channel")
        .setDescription("Select a channel for welcome messages")
        .addChannelTypes(ChannelType.GuildText)
        .setRequired(true)
    )
    .addStringOption(option =>
      option.setName("message")
        .setDescription("Enter the welcome message. Use {user} to mention the member.")
        .setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .setDMPermission(false),

  async execute(interaction) {
    const channel = interaction.options.getChannel("channel");
    const message = interaction.options.getString("message");

    // Optional: warn if {user} is not in message
    if (!message.includes("{user}")) {
      return interaction.reply({
        content: "⚠️ Your message is missing `{user}`. Please include it to mention the new member.",
        ephemeral: true
      });
    }

    try {
      await Welcome.findOneAndUpdate(
        { guildId: interaction.guild.id },
        { channelId: channel.id, message },
        { upsert: true, new: true }
      );

      await interaction.reply({
        content: `✅ Welcome system updated!\n\n**Channel:** <#${channel.id}>\n**Message Preview:** ${message.replace(/{user}/g, `<@${interaction.user.id}>`)}\n\nℹ️ In actual use, {user} will tag the new member.`,
        ephemeral: true
      });
    } catch (err) {
      console.error("❌ Welcome command error:", err);
      await interaction.reply({
        content: "❌ Failed to update welcome settings. Please try again later.",
        ephemeral: true
      });
    }
  }
};