const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('dragall')
    .setDescription('Move all members from one voice channel to another')
    .addChannelOption(option =>
      option.setName('from-vc')
        .setDescription('Voice channel to move members from')
        .setRequired(true))
    .addChannelOption(option =>
      option.setName('to-vc')
        .setDescription('Voice channel to move members to')
        .setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.MoveMembers),

  async execute(interaction) {
    const fromVC = interaction.options.getChannel('from-vc');
    const toVC = interaction.options.getChannel('to-vc');

    // Validate channel types
    if (fromVC.type !== 2 || toVC.type !== 2) {
      return interaction.reply({ content: 'Please select valid voice channels.', ephemeral: true });
    }

    const membersToMove = fromVC.members;

    if (membersToMove.size === 0) {
      return interaction.reply({ content: `No members found in ${fromVC.name}.`, ephemeral: true });
    }

    let movedCount = 0;
    for (const member of membersToMove.values()) {
      try {
        await member.voice.setChannel(toVC);
        movedCount++;
      } catch (err) {
        console.log(`❌ Failed to move ${member.user.tag}`);
      }
    }

    await interaction.reply(`✅ Moved **${movedCount}** member(s) from ${fromVC.name} to ${toVC.name}.`);
  }
};