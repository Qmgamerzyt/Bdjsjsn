const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const Punishment = require("../../models/Punishment");
const Warning = require("../../models/Warn");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("clearpunishments")
    .setDescription("🧹 Clear all punishment and warning history of a user (Owner only)")
    .addUserOption(option =>
      option.setName("user")
        .setDescription("The user to clear punishments for")
        .setRequired(true)
    )
    .setDMPermission(false), // Only usable in servers

  async execute(interaction) {
    // Only allow server owner to run this
    if (interaction.user.id !== interaction.guild.ownerId) {
      return interaction.reply({
        content: "❌ Only the **server owner** can use this command.",
        ephemeral: true
      });
    }

    const target = interaction.options.getUser("user");

    // Delete punishments and warnings from DB
    const [punishmentsDeleted, warningsDeleted] = await Promise.all([
      Punishment.deleteMany({ userId: target.id, guildId: interaction.guildId }),
      Warning.deleteMany({ userId: target.id, guildId: interaction.guildId })
    ]);

    const embed = new EmbedBuilder()
      .setTitle("🧹 Punishment History Cleared")
      .setDescription(`All punishments and warnings for **${target.tag}** have been deleted.`)
      .addFields(
        { name: "Punishments Deleted", value: `${punishmentsDeleted.deletedCount}`, inline: true },
        { name: "Warnings Deleted", value: `${warningsDeleted.deletedCount}`, inline: true }
      )
      .setColor("Green")
      .setFooter({ text: `Cleared by ${interaction.user.tag}` })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] }); // Public response
  }
};