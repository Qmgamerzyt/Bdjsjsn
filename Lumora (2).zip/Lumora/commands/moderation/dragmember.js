const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('dragmember')
    .setDescription('Move a specific member to a selected voice channel')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('User to drag')
        .setRequired(true))
    .addChannelOption(option =>
      option.setName('vc')
        .setDescription('Voice channel to move the user to')
        .setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.MoveMembers),

  async execute(interaction) {
    const user = interaction.options.getUser('user');
    const channel = interaction.options.getChannel('vc');
    const member = interaction.guild.members.cache.get(user.id);

    // Validate voice channel type
    if (channel.type !== 2) {
      return interaction.reply({ content: 'Please select a valid voice channel.', ephemeral: true });
    }

    if (!member || !member.voice.channel) {
      return interaction.reply({ content: `${user.tag} is not connected to any voice channel.`, ephemeral: true });
    }

    try {
      await member.voice.setChannel(channel);
      await interaction.reply(`${user.tag} has been moved to ${channel.name}.`);
    } catch (err) {
      console.error(err);
      await interaction.reply({ content: `Failed to move ${user.tag}.`, ephemeral: true });
    }
  }
};