const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const Punishment = require("../../models/Punishment");

function parseDuration(input) {
  const match = input.match(/^(\d+)([smhd])$/);
  if (!match) return null;

  const value = parseInt(match[1]);
  const unit = match[2];

  const multipliers = {
    s: 1000,
    m: 60_000,
    h: 3_600_000,
    d: 86_400_000,
  };

  return value * multipliers[unit];
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName("timeout")
    .setDescription("Timeout a member for a specific duration.")
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption(option =>
      option.setName("user").setDescription("User to timeout").setRequired(true)
    )
    .addStringOption(option =>
      option.setName("duration")
        .setDescription("Duration (e.g. 10m, 1h, 2d)")
        .setRequired(true)
    )
    .addStringOption(option =>
      option.setName("reason")
        .setDescription("Reason for timeout")
        .setRequired(false)
    ),

  async execute(interaction) {
    const member = interaction.options.getMember("user");
    const durationStr = interaction.options.getString("duration");
    const reason = interaction.options.getString("reason") || "No reason provided";

    if (!member || !member.moderatable || typeof member.timeout !== "function") {
      return interaction.reply({
        content: "❌ I can't timeout this user. Check role hierarchy or permissions.",
        ephemeral: true,
      });
    }

    const durationMs = parseDuration(durationStr);

    if (!durationMs || durationMs < 1000 || durationMs > 28 * 24 * 60 * 60 * 1000) {
      return interaction.reply({
        content: "❌ Invalid duration. Use formats like `10m`, `1h`, `2d`. Max is 28 days.",
        ephemeral: true,
      });
    }

    try {
      // Send DM
      await member.send(
        `🚫 You have been timed out in **${interaction.guild.name}** for **${durationStr}**.\n📄 Reason: ${reason}`
      ).catch(() => {
        console.log(`⚠️ Could not send timeout DM to ${member.user.tag}`);
      });

      // Apply timeout
      await member.timeout(durationMs, reason);

      // Save to DB
      await Punishment.create({
        userId: member.id,
        guildId: interaction.guild.id,
        type: "timeout",
        reason,
        moderatorId: interaction.user.id,
        duration: durationStr,
        date: new Date()
      });

      // Confirm in chat
      return interaction.reply({
        content: `✅ <@${member.id}> has been timed out for **${durationStr}**.\n📄 Reason: ${reason}`,
        allowedMentions: { users: [] },
      });
    } catch (error) {
      console.error("❌ Timeout error:", error);
      return interaction.reply({
        content: "❌ Failed to timeout the user.",
        ephemeral: true,
      });
    }
  },
};