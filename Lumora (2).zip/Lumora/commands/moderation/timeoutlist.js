// commands/timeoutlist.js
const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('timeoutlist')
    .setDescription('Shows all users who are currently timed out')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    await interaction.deferReply();

    const members = await interaction.guild.members.fetch();
    const timedOutMembers = members.filter(member => member.communicationDisabledUntilTimestamp && member.communicationDisabledUntilTimestamp > Date.now());

    if (timedOutMembers.size === 0) {
      return interaction.editReply('✅ No users are currently timed out.');
    }

    const embed = new EmbedBuilder()
      .setTitle('🕒 Timed Out Users')
      .setColor('Orange')
      .setTimestamp();

    timedOutMembers.forEach(member => {
      const timeoutUntil = `<t:${Math.floor(member.communicationDisabledUntilTimestamp / 1000)}:R>`;
      embed.addFields({
        name: member.user.tag,
        value: `Timeout ends: ${timeoutUntil}`,
        inline: false
      });
    });

    return interaction.editReply({ embeds: [embed] });
  }
};