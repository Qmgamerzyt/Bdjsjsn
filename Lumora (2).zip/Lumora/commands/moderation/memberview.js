// commands/moderation/memberview.js
const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
} = require("discord.js");

const bannedWords = ["badword1", "toxicword", "anotherbadword"]; // customize as needed

module.exports = {
  data: new SlashCommandBuilder()
    .setName("memberview")
    .setDescription("🔍 Advanced insights about a member (mod only)")
    .addUserOption(option =>
      option.setName("user")
        .setDescription("The user to inspect")
        .setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),

  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });

    const user = interaction.options.getUser("user");
    const member = interaction.guild.members.cache.get(user.id);
    const client = interaction.client;

    if (!member) {
      return interaction.editReply({ content: "❌ Member not found in this server." });
    }

    const userRoles = member.roles.cache
      .filter(role => role.id !== interaction.guild.id)
      .map(role => `<@&${role.id}>`)
      .join(", ") || "None";

    const mutualGuilds = client.guilds.cache.filter(g => g.members.cache.has(user.id));
    const mutualList = mutualGuilds.map(g => g.name).join(", ") || "No mutual servers";

    const recentMessages = [];
    const channels = interaction.guild.channels.cache
      .filter(c => c.isTextBased() && c.viewable)
      .first(10); // Only scan 10 channels max

    const fetchPromises = channels.map(async channel => {
      try {
        const messages = await channel.messages.fetch({ limit: 20 });
        const userMsgs = messages.filter(m => m.author.id === user.id);
        recentMessages.push(...userMsgs.map(m => m.content));
      } catch (e) {
        // skip if permission or fetch error
      }
    });

    await Promise.allSettled(fetchPromises);

    const matched = recentMessages.filter(msg =>
      bannedWords.some(word => msg.toLowerCase().includes(word.toLowerCase()))
    );

    const embed = new EmbedBuilder()
      .setTitle(`🕵️ Member Overview: ${user.tag}`)
      .setThumbnail(user.displayAvatarURL({ dynamic: true }))
      .setColor("#00b0f4")
      .addFields(
        { name: "🆔 User ID", value: user.id, inline: true },
        { name: "📆 Account Created", value: `<t:${Math.floor(user.createdTimestamp / 1000)}:R>`, inline: true },
        { name: "📥 Joined Server", value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>`, inline: true },
        { name: "🎭 Roles", value: userRoles, inline: false },
        { name: "🔗 Mutual Servers", value: mutualList, inline: false },
        { name: "💬 Messages Scanned", value: `${recentMessages.length}`, inline: true },
        { name: "🚫 Banned Word Matches", value: `${matched.length}`, inline: true }
      )
      .setFooter({ text: `Requested by ${interaction.user.tag}` })
      .setTimestamp();

    return interaction.editReply({ embeds: [embed] });
  }
};