const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require("discord.js");
const ms = require("ms");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("tempremoverole")
    .setDescription("⏳ Temporarily remove one or more roles from mentioned users.")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
    .addStringOption(option =>
      option.setName("users")
        .setDescription("Mention users (e.g. @User1 @User2)")
        .setRequired(true))
    .addStringOption(option =>
      option.setName("roles")
        .setDescription("Mention roles (e.g. @Muted @Jailed)")
        .setRequired(true))
    .addStringOption(option =>
      option.setName("duration")
        .setDescription("Duration like 10m, 1h, 2d")
        .setRequired(true)),

  async execute(interaction) {
    await interaction.deferReply(); // Prevent "Unknown interaction"

    const usersRaw = interaction.options.getString("users");
    const rolesRaw = interaction.options.getString("roles");
    const duration = interaction.options.getString("duration");
    const durationMs = ms(duration);

    if (!durationMs || durationMs < 1000) {
      return interaction.editReply("❌ Invalid duration. Use like `10m`, `1h`, `1d`");
    }

    const userIds = [...usersRaw.matchAll(/<@!?(\d+)>/g)].map(match => match[1]);
    const roleIds = [...rolesRaw.matchAll(/<@&(\d+)>/g)].map(match => match[1]);

    const removed = [];
    const failed = [];

    for (const userId of userIds) {
      const member = await interaction.guild.members.fetch(userId).catch(() => null);
      if (!member) {
        failed.push(`❌ <@${userId}> (User not found)`);
        continue;
      }

      for (const roleId of roleIds) {
        const role = interaction.guild.roles.cache.get(roleId);
        if (!role || !member.roles.cache.has(roleId)) {
          failed.push(`❌ ${member.user.tag} - <@&${roleId}> (Not assigned or invalid)`);
          continue;
        }

        if (
          !interaction.guild.members.me.permissions.has(PermissionFlagsBits.ManageRoles) ||
          role.position >= interaction.guild.members.me.roles.highest.position
        ) {
          failed.push(`❌ ${member.user.tag} - <@&${roleId}> (Missing permission or role too high)`);
          continue;
        }

        try {
          await member.roles.remove(role);
          removed.push(`✅ ${member.user.tag} ➖ <@&${roleId}> for \`${duration}\``);

          setTimeout(async () => {
            try {
              await member.roles.add(role);
              console.log(`✅ Restored ${role.name} to ${member.user.tag}`);
            } catch (err) {
              console.log(`❌ Failed to re-add ${role.name} to ${member.user.tag}`);
            }
          }, durationMs);
        } catch {
          failed.push(`❌ ${member.user.tag} - <@&${roleId}> (Error during removal)`);
        }
      }
    }

    const embed = new EmbedBuilder()
      .setTitle("⏳ Temporary Role Removal Summary")
      .setColor("Red")
      .addFields(
        { name: "Duration", value: `\`${duration}\``, inline: true },
        { name: "Removed", value: removed.length ? removed.join("\n") : "None", inline: false },
        { name: "Failed", value: failed.length ? failed.join("\n") : "None", inline: false }
      )
      .setFooter({ text: `Requested by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() })
      .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
  }
};