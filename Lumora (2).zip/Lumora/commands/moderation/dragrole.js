const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('dragrole')
    .setDescription('Move all VC-connected members of a role from one voice channel to another')
    .addRoleOption(option =>
      option.setName('role')
        .setDescription('Role to drag from')
        .setRequired(true))
    .addChannelOption(option =>
      option.setName('from-vc')
        .setDescription('Voice channel to move members from')
        .setRequired(true))
    .addChannelOption(option =>
      option.setName('to-vc')
        .setDescription('Voice channel to move members to')
        .setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.MoveMembers),

  async execute(interaction) {
    const role = interaction.options.getRole('role');
    const fromVC = interaction.options.getChannel('from-vc');
    const toVC = interaction.options.getChannel('to-vc');

    // Validate voice channel types
    if (fromVC.type !== 2 || toVC.type !== 2) {
      return interaction.reply({ content: 'Please select valid voice channels.', ephemeral: true });
    }

    const membersToMove = fromVC.members.filter(member => member.roles.cache.has(role.id));

    if (membersToMove.size === 0) {
      return interaction.reply({
        content: `No members with the ${role.name} role are connected to ${fromVC.name}.`,
        ephemeral: true
      });
    }

    let movedCount = 0;
    for (const member of membersToMove.values()) {
      try {
        await member.voice.setChannel(toVC);
        movedCount++;
      } catch (err) {
        console.log(`❌ Failed to move ${member.user.tag}`);
      }
    }

    await interaction.reply(`✅ Moved **${movedCount}** member(s) with role ${role.name} from ${fromVC.name} to ${toVC.name}.`);
  }
};