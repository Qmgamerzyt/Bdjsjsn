const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require("discord.js");
const Punishment = require("../../models/Punishment");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("kick")
    .setDescription("Kick a member from the server.")
    .addUserOption(option =>
      option.setName("target")
        .setDescription("The user to kick")
        .setRequired(true))
    .addStringOption(option =>
      option.setName("reason")
        .setDescription("Reason for kick")
        .setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),

  async execute(interaction) {
    const targetUser = interaction.options.getUser("target");
    const reason = interaction.options.getString("reason") || "No reason provided";
    const member = interaction.guild.members.cache.get(targetUser.id);

    if (!member) {
      return interaction.reply({
        content: "❌ Could not find that user in this server.",
        ephemeral: true
      });
    }

    if (!member.kickable) {
      return interaction.reply({
        content: "❌ I cannot kick this user. They may have a higher role or special permissions.",
        ephemeral: true
      });
    }

    // DM the user
    try {
      const dmEmbed = new EmbedBuilder()
        .setColor("Red")
        .setTitle(`🚫 You have been kicked from ${interaction.guild.name}`)
        .setDescription(`**Reason:** ${reason}`)
        .setTimestamp();

      await targetUser.send({ embeds: [dmEmbed] });
    } catch (err) {
      console.warn(`⚠️ Could not send DM to ${targetUser.tag}`);
    }

    // Kick and log punishment
    try {
      await member.kick(reason);

      await Punishment.create({
        userId: targetUser.id,
        guildId: interaction.guild.id,
        type: "kick",
        reason: reason,
        moderatorId: interaction.user.id,
        timestamp: new Date()
      });

      const logEmbed = new EmbedBuilder()
        .setColor("Orange")
        .setTitle("👢 Member Kicked")
        .addFields(
          { name: "User", value: `${targetUser.tag} (${targetUser.id})`, inline: true },
          { name: "Moderator", value: `${interaction.user.tag}`, inline: true },
          { name: "Reason", value: reason, inline: false }
        )
        .setTimestamp();

      await interaction.reply({ embeds: [logEmbed] });

    } catch (error) {
      console.error("❌ Kick error:", error);
      await interaction.reply({
        content: "❌ Failed to kick the user.",
        ephemeral: true
      });
    }
  }
};