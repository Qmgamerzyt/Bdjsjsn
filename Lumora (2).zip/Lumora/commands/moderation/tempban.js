const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const ms = require('ms');
const Punishment = require("../../models/Punishment");

module.exports = {
  data: new SlashCommandBuilder()
    .setName('tempban')
    .setDescription('Temporarily ban a user from the server')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('User to temporarily ban')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('duration')
        .setDescription('Ban duration (e.g., 10m, 2h, 1d)')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('reason')
        .setDescription('Reason for the ban')
        .setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

  async execute(interaction) {
    const user = interaction.options.getUser('user');
    const member = interaction.guild.members.cache.get(user.id);
    const duration = interaction.options.getString('duration');
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const executor = interaction.user;

    const durationMs = ms(duration);
    if (!durationMs || durationMs < 1000) {
      return interaction.reply({ content: '❌ Invalid duration. Use formats like `5m`, `1h`, `1d`.', ephemeral: true });
    }

    if (!member) {
      return interaction.reply({ content: '❌ User not found in the server.', ephemeral: true });
    }

    if (!member.bannable) {
      return interaction.reply({ content: '❌ I cannot ban this user. They might have higher permissions or roles.', ephemeral: true });
    }

    // Attempt DM
    try {
      const dmEmbed = new EmbedBuilder()
        .setTitle(`🚫 Temporarily Banned from ${interaction.guild.name}`)
        .setDescription(`**Duration:** ${duration}\n**Reason:** ${reason}`)
        .setColor('Red')
        .setTimestamp();

      await user.send({ embeds: [dmEmbed] });
    } catch (err) {
      console.log(`⚠️ Could not send DM to ${user.tag}`);
    }

    // Ban user
    await member.ban({ reason });

    // Save in Punishment model
    await Punishment.create({
      userId: user.id,
      guildId: interaction.guild.id,
      type: "ban",
      reason,
      moderatorId: executor.id,
      duration: duration,
      date: new Date()
    });

    // Confirm response
    const replyEmbed = new EmbedBuilder()
      .setColor('Red')
      .setTitle(`${user.tag} has been temporarily banned`)
      .addFields(
        { name: 'Moderator', value: executor.toString(), inline: true },
        { name: 'Duration', value: duration, inline: true },
        { name: 'Reason', value: reason, inline: false }
      )
      .setTimestamp();

    await interaction.reply({ embeds: [replyEmbed] });

    // Schedule unban
    setTimeout(async () => {
      try {
        await interaction.guild.members.unban(user.id, 'Temporary ban expired');

        try {
          const unbanUser = await interaction.client.users.fetch(user.id);
          const unbanDM = new EmbedBuilder()
            .setTitle(`✅ Unbanned from ${interaction.guild.name}`)
            .setDescription(`Your temporary ban has expired.`)
            .setColor('Green')
            .setTimestamp();

          await unbanUser.send({ embeds: [unbanDM] });
        } catch {
          console.log(`⚠️ Could not DM ${user.tag} after unban`);
        }

        console.log(`✅ ${user.tag} has been automatically unbanned.`);
      } catch (err) {
        console.error(`❌ Failed to auto-unban ${user.id}:`, err);
      }
    }, durationMs);
  }
};