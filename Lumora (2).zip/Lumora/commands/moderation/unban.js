// commands/unban.js
const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unban')
    .setDescription('Unban a user from the server')
    .addStringOption(option =>
      option.setName('userid')
        .setDescription('ID of the user to unban')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('reason')
        .setDescription('Reason for the unban')
        .setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

  async execute(interaction) {
    const userId = interaction.options.getString('userid');
    const reason = interaction.options.getString('reason') || 'No reason provided';

    try {
      // Fetch the banned user
      const bannedUsers = await interaction.guild.bans.fetch();
      const bannedUser = bannedUsers.get(userId);

      if (!bannedUser) {
        return interaction.reply({ content: '❌ User is not banned.', ephemeral: true });
      }

      // Always send DM before unbanning
      try {
        const userToDM = await interaction.client.users.fetch(userId);

        const dmEmbed = new EmbedBuilder()
          .setTitle(`You were unbanned from ${interaction.guild.name}`)
          .setDescription(`**Reason:** ${reason}`)
          .setColor('Green')
          .setTimestamp();

        await userToDM.send({ embeds: [dmEmbed] });
      } catch (err) {
        console.log(`❌ Failed to send DM to user ID ${userId}`);
      }

      // Unban the user
      await interaction.guild.members.unban(userId, reason);

      const embed = new EmbedBuilder()
        .setTitle(`User Unbanned`)
        .addFields(
          { name: 'User ID', value: userId, inline: true },
          { name: 'Reason', value: reason, inline: true },
        )
        .setColor('Green')
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });

    } catch (error) {
      console.error(error);
      return interaction.reply({ content: '❌ An error occurred while trying to unban the user.', ephemeral: true });
    }
  }
};