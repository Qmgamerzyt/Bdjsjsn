const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require("discord.js");
const Warn = require("../../models/Warn");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("removewarn")
    .setDescription("Remove warnings from a user")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addUserOption(option =>
      option.setName("user")
        .setDescription("The user to remove warnings from")
        .setRequired(true)
    )
    .addStringOption(option =>
      option.setName("amount")
        .setDescription("Number of warnings to remove or 'all' to remove all")
        .setRequired(true)
    ),

  async execute(interaction) {
    const targetUser = interaction.options.getUser("user");
    const amount = interaction.options.getString("amount");
    const guildId = interaction.guildId;
    const userId = targetUser.id;

    const warnings = await Warn.find({ userId, guildId });

    if (warnings.length === 0) {
      return interaction.reply({
        content: `⚠️ <@${userId}> has no warnings.`,
        ephemeral: true
      });
    }

    if (amount.toLowerCase() === "all") {
      await Warn.deleteMany({ userId, guildId });

      const dmMsg = `🧹 All your warnings have been cleared in **${interaction.guild.name}**.`;
      try { await targetUser.send(dmMsg); } catch (e) {}

      const embed = new EmbedBuilder()
        .setColor("Green")
        .setTitle("✅ All Warnings Cleared")
        .setDescription(`Successfully removed all warnings for <@${userId}>.`);

      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    const numToRemove = parseInt(amount);
    if (isNaN(numToRemove) || numToRemove <= 0) {
      return interaction.reply({
        content: "❌ Please provide a valid number or use `all`.",
        ephemeral: true
      });
    }

    const toDelete = warnings.slice(0, numToRemove);
    for (const warn of toDelete) {
      await Warn.findByIdAndDelete(warn._id);
    }

    const dmMsg = `⚠️ ${toDelete.length} of your warning(s) have been removed in **${interaction.guild.name}**.`;
    try { await targetUser.send(dmMsg); } catch (e) {}

    const embed = new EmbedBuilder()
      .setColor("Orange")
      .setTitle("⚠️ Warnings Removed")
      .setDescription(`Removed **${toDelete.length}** warning(s) for <@${userId}>.`);

    await interaction.reply({ embeds: [embed], ephemeral: true });
  }
};