// commands/banlist.js
const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('banlist')
    .setDescription('Shows a list of all banned users')
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

  async execute(interaction) {
    await interaction.deferReply();

    try {
      const bans = await interaction.guild.bans.fetch();

      if (bans.size === 0) {
        return interaction.editReply('✅ No users are currently banned.');
      }

      const embed = new EmbedBuilder()
        .setTitle('🚫 Banned Users')
        .setColor('Red')
        .setTimestamp();

      for (const [id, ban] of bans) {
        embed.addFields({
          name: `${ban.user.tag} (${ban.user.id})`,
          value: `Username: ${ban.user.username}`,
          inline: false,
        });
      }

      await interaction.editReply({ embeds: [embed] });

    } catch (err) {
      console.error('Error fetching bans:', err);
      return interaction.editReply('❌ Could not fetch ban list.');
    }
  }
};