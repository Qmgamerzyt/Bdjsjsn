const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const Punishment = require("../../models/Punishment");

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('🔨 Ban a user from the server')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('User to ban')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('reason')
        .setDescription('Reason for the ban')
        .setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

  async execute(interaction) {
    const user = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'No reason provided';

    const member = interaction.guild.members.cache.get(user.id);
    const moderator = interaction.user;

    if (!member) {
      return interaction.reply({ content: '❌ User not found in the server.', ephemeral: true });
    }

    if (!member.bannable) {
      return interaction.reply({ content: '❌ I cannot ban this user. They may have higher permissions or roles.', ephemeral: true });
    }

    // Try to DM the user
    try {
      const dmEmbed = new EmbedBuilder()
        .setTitle(`🚫 You were banned from ${interaction.guild.name}`)
        .setDescription(`**Reason:** ${reason}`)
        .setColor('Red')
        .setTimestamp();

      await user.send({ embeds: [dmEmbed] });
    } catch (err) {
      console.log(`⚠️ Could not send DM to ${user.tag}`);
    }

    // Ban the user
    try {
      await member.ban({ reason });

      // Save punishment in DB
      await Punishment.create({
        userId: user.id,
        guildId: interaction.guild.id,
        type: "ban",
        reason,
        moderatorId: moderator.id,
        timestamp: new Date()
      });

      // Success response
      const successEmbed = new EmbedBuilder()
        .setTitle(`${user.tag} has been banned`)
        .addFields(
          { name: '👮‍♂️ Banned By', value: moderator.toString(), inline: true },
          { name: '📝 Reason', value: reason, inline: true },
        )
        .setColor('Red')
        .setTimestamp();

      await interaction.reply({ embeds: [successEmbed] });
    } catch (error) {
      console.error("❌ Failed to ban:", error);
      await interaction.reply({
        content: '❌ Something went wrong while trying to ban the user.',
        ephemeral: true
      });
    }
  }
};