const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require("discord.js");
const Punishment = require("../../models/Punishment");
const Warning = require("../../models/Warn");
const moment = require("moment");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("punishmenthistory")
    .setDescription("📚 View full punishment and warning history of a member")
    .addUserOption(option =>
      option.setName("user")
        .setDescription("The user to view history for")
        .setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers) // only visible/usable by staff
    .setDMPermission(false),

  async execute(interaction) {
    const target = interaction.options.getUser("user");

    const [punishments, warnings] = await Promise.all([
      Punishment.find({ userId: target.id, guildId: interaction.guildId }),
      Warning.find({ userId: target.id, guildId: interaction.guildId })
    ]);

    if (punishments.length === 0 && warnings.length === 0) {
      return interaction.reply({
        content: `✅ ${target.tag} has a clean record. No punishments or warnings found.`,
        ephemeral: false // Public reply
      });
    }

    const entries = [
      ...punishments.map(p => ({
        type: p.type.toUpperCase(),
        reason: p.reason || "No reason",
        date: p.date || p.timestamp || new Date(),
        moderatorId: p.moderatorId,
        duration: p.duration || null,
      })),
      ...warnings.map(w => ({
        type: "WARN",
        reason: w.reason || "No reason",
        date: w.timestamp || new Date(),
        moderatorId: w.moderatorId || "Unknown",
        duration: null,
      })),
    ];

    entries.sort((a, b) => b.date - a.date); // newest first

    const fields = entries.map((entry, i) => ({
      name: `#${i + 1} - ${entry.type}`,
      value:
        `🧑‍⚖️ **Moderator:** <@${entry.moderatorId}>\n` +
        `📝 **Reason:** ${entry.reason}\n` +
        `⏱️ **When:** ${moment(entry.date).fromNow()}` +
        (entry.duration ? `\n⏳ **Duration:** ${entry.duration}` : ""),
      inline: false
    }));

    const embed = new EmbedBuilder()
      .setTitle(`📚 Punishment History: ${target.tag}`)
      .setThumbnail(target.displayAvatarURL({ dynamic: true }))
      .addFields(fields.slice(0, 25))
      .setColor("DarkRed")
      .setFooter({ text: `Requested by ${interaction.user.tag}` })
      .setTimestamp();

    return interaction.reply({ embeds: [embed] }); // ← PUBLIC response
  }
};