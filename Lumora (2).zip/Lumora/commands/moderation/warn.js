const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const Warning = require("../../models/Warn");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("warn")
    .setDescription("🚫 Warn multiple users with multiple warnings each")
    .addStringOption(option =>
      option
        .setName("users")
        .setDescription("Mention users separated by spaces (e.g. @User1 @User2)")
        .setRequired(true)
    )
    .addStringOption(option =>
      option
        .setName("reason")
        .setDescription("Reason for the warnings")
        .setRequired(true)
    )
    .addIntegerOption(option =>
      option
        .setName("count")
        .setDescription("How many warnings to apply to each user (max 10)")
        .setMinValue(1)
        .setMaxValue(10)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const rawUsers = interaction.options.getString("users");
    const reason = interaction.options.getString("reason");
    const count = interaction.options.getInteger("count") || 1;

    // Extract user IDs from mentions
    const userIds = rawUsers.match(/<@!?(\d+)>/g)?.map(u => u.replace(/[<@!>]/g, ""));
    if (!userIds || userIds.length === 0) {
      return interaction.reply({ content: "❌ No valid user mentions found.", ephemeral: true });
    }

    let success = 0;
    let failed = 0;

    for (const userId of userIds) {
      try {
        // Save warnings
        for (let i = 0; i < count; i++) {
          await Warning.create({
            userId,
            guildId: interaction.guildId,
            moderatorId: interaction.user.id,
            reason,
            timestamp: new Date()
          });
        }

        // Try to DM user (non-blocking)
        try {
          const user = await interaction.client.users.fetch(userId);
          await user.send(
            `⚠️ You have received **${count} warning(s)** in **${interaction.guild.name}** for:\n${reason}`
          );
        } catch (dmErr) {
          console.warn(`⚠️ Couldn't DM user ${userId}:`, dmErr.message);
        }

        success++;
      } catch (err) {
        console.error(`❌ Failed to warn ${userId}:`, err.message);
        failed++;
      }
    }

    return interaction.reply({
      content: `✅ Successfully warned ${success} user(s) with **${count} warning(s)** each.${failed > 0 ? `\n❌ Failed to warn ${failed} user(s).` : ""}`,
      ephemeral: true,
    });
  },
};